#!/usr/bin/python

# Copyright: (c) 2018, Your Name <your.email@example.org>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = '''
---
module: my_test

short_description: This module creates a text file with given content on a specified path.

version_added: "1.0.0"

description:
    - This module will create a text file on the remote host at a specified path with the given content.

options:
    path:
        description: The full path where the file should be created.
        required: true
        type: str
    content:
        description: The content that should be written into the file.
        required: true
        type: str

author:
    - Your Name (@yourGitHubHandle)
'''

EXAMPLES = '''
- name: Create a text file with content
  my_namespace.my_collection.my_test:
    path: /tmp/test_file.txt
    content: "Hello, Ansible!"
'''

RETURN = '''
path:
    description: The path to the file created.
    type: str
    returned: always
    sample: "/tmp/test_file.txt"
content:
    description: The content written into the file.
    type: str
    returned: always
    sample: "Hello, Ansible!"
'''

from ansible.module_utils.basic import AnsibleModule

def run_module():
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True)
    )

    result = dict(
        changed=False,
        path='',
        content=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Check if file already exists
    try:
        with open(module.params['path'], 'r') as file:
            existing_content = file.read()
        if existing_content == module.params['content']:
            module.exit_json(changed=False, path=module.params['path'], content=existing_content)
    except FileNotFoundError:
        pass  # No file exists, will create a new one

    # Create or update the file
    with open(module.params['path'], 'w') as file:
        file.write(module.params['content'])

    result['changed'] = True
    result['path'] = module.params['path']
    result['content'] = module.params['content']

    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()
